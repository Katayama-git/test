CREATE TABLE example_menu
(
    id   SERIAL PRIMARY KEY,
    name varchar(80) NOT NULL
);