CREATE TABLE example_stock
(
    item_id int NOT NULL,
    amount int NOT NULL
);