//DOMが読み込まれたときにfetchTodo()を呼び出す処理。
document.addEventListener("DOMContentLoaded", fetchTodo);
//サーバーにHTTPリクエストを送り、データテーブルにあるレコードを受け取る処理。
async function fetchTodo() {
    //HTTPリクエストに使う値をローカルストレージから取得する処理。
    let userId = localStorage.getItem("userid");
    //サーバにHTTPリクエストを送る処理。
    const response = await fetch(`http://192.168.56.101:8080/sample/todo/${userId}`);
    //リクエストが失敗した時の処理。
    if (!response.ok) {
        throw new Error("Could not fetch todo");
    }
    //リクエストをして帰ってきた戻り値をJSON形式に変換する処理。
    var jsonData = await response.json();
    //変換したJSON形式のデータの長さに応じてループさせる処理。
    for(var count = 0; count < jsonData.length; count++){
        var id = await jsonData[count].id;
        var contentJson = await jsonData[count].content;
        var box = document.createElement("div");
            box.id = id;
            box.className = "box";
        var date = document.createElement("input");
            date.type = "date";
            date.className = "date";
        var today = new Date().toISOString().split('T')[0];
            date.min = today;
        var textarea = document.createElement("textarea");
            textarea.placeholder = "The use of | is prohibited.Within the 500 words limit.";
            textarea.className = "textarea";
            textarea.maxLength = "500";
            textarea.addEventListener('keydown', function(event) {
                const restrictedChars = ["|"];
                
                const key = event.key.toLowerCase();
                
                if (restrictedChars.includes(key)) {
                    event.preventDefault();
                }
            });
            //textarea.style.overflow = "hidden";
            textarea.draggable = true;
            box.addEventListener("dragstart", function (event) {
                draggedElementId = event.target.parentNode.id;
            });
        var label = document.createElement("label");
            label.backgroundColor = "aqua";
            label.textContent = "Due Date";
        
        if(contentJson !==null){
        var contentJsonSplit = contentJson.split("|");
            date.value = contentJsonSplit[0];
            textarea.value = contentJsonSplit[1];
        }
        /*
        console.log(new Date(),"new Date")
        console.log(today,"today");
        console.log(date.value,"date value")
        if(date.value < today ){
            label.style.backgroundColor = "lightcoral";
            date.style.backgroundColor = "lightcoral";
            textarea.style.backgroundColor = "lightcoral";
            box.style.backgroundColor = "lightcoral";
        }
        if(date.value.includes(null)){
            label.style.backgroundColor = "aqua";
            date.style.backgroundColor = "aqua";
            textarea.style.backgroundColor = "aqua";
            box.style.backgroundColor = "aqua"; 
        }
        */
            box.appendChild(label);
            box.appendChild(date);
            box.appendChild(textarea);
        const container = document.getElementById("container");
            if (!container) {
                throw new Error("Could not find container");
            };
            container.className = "draggable-container";
            container.appendChild(box);

}
    /*todos.innerHTML="";
    const todoDiv = document.createElement("table");
    todoDiv.innerHTML=
    "<th>USER ID</th><th>DUE DATE</th><th>CONTENT</th><th>CREATED AT</th>";
    todoJson.todos.forEach((todo) => {
        todoDiv.innerHTML += `
        <tr>
            <td>${todo.userid}</td>
            <td>${todo.duedate}</td>
            <td>${todo.content}</td>
            <td>${todo.createdat}</td>
            <td>
            <button onclick="DeleteTodo(${todo.userid})">DELETE</button>
            </td>
        </tr>`;*/
    /*
        var ones = responseJson.split('|');
    console.log(ones);
    for (var count = 0; count < ones.length; count++) {
        var one = await ones[count];
        let textareaCount = localStorage.getItem("textareaCount");
        if(textareaCount === null){
        textareaCount = 0
        }else{
        textareaCount = parseInt(textareaCount);
        }
        var textarea = document.createElement("textarea");
        textarea.id = textareaCount;
        textareaCount++;
        localStorage.setItem("textareaCount",textareaCount);
        textarea.style.backgroundColor = "aqua";
        textarea.placeholder = "タスク内容";
        textarea.style.fontSize = "16px";
        textarea.style.margin = "10px";
        textarea.style.padding = "15px";
        textarea.style.cursor = "pointer";
        textarea.style.boxShadow = "5px 5px 5px rgba(0,0,0,0.5)";
        textarea.draggable = true;
        var top = lastElementTop + lastElementHeight;
        var left = textarea.offsetLeft;
        textarea.style.top = top + "px";
        textarea.style.left = left + "px";
        lastElementTop = top;
        lastElementHeight = textarea.offsetHeight;
        textarea.addEventListener("dragstart", function (event) {
            draggedElementId = event.target.id;
        });
        textarea.value = one;
        container.appendChild(textarea);
    }
    */
            var container = document.getElementById("container");
            var children = container.getElementsByClassName("box");
            //付箋をログイン日に近い順に並べなおす処理。
            var sortedChildren = Array.from(children).sort(function(a,b){
                var dateA = new Date(a.childNodes[1].value);
                var dateB = new Date(b.childNodes[1].value);
                var currentDate = new Date();

                var diffA = currentDate - dateA;
                var diffB = currentDate - dateB;

                return diffB - diffA;
            });
            //並べなおした配列をメイン画面に追加する処理。
            sortedChildren.forEach(function(child){
                container.appendChild(child);
            });
}