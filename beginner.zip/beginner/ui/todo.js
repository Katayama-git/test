//ユーザーがデータベースに登録してある自分のユーザーネームとパスワードを入力し、
//それらの値を用いてサーバーにHTTPリクエストを送って登録してある値かを判断してメイン画面に遷移するかどうかを分岐させる処理。
async function login() {
    document.getElementById("loading-screen").style.display = "flex";
    var username = document.getElementById("username_login").value.replace(/[\s\u{3000}]/ug, '');
    if(!username){
        alert("UserName can not to be empty or Using space only in your username is not allowed");
        document.getElementById("loading-screen").style.display = "none";
        return;
    }else if(username.includes("\\")){
        alert("The use of backslash is not allowed");
        document.getElementById("loading-screen").style.display = "none";
        return;
    }
    var password  = document.getElementById("password_login").value.replace(/[\s\u{3000}]/ug, '');
    if(!password){
        alert("PassWord can not to be empty or Using space only in your password is not allowed");
        document.getElementById("loading-screen").style.display = "none";
        return;
    }else if(password.includes("\\")){
        alert("The use of backslash is not allowed");
        document.getElementById("loading-screen").style.display = "none";
        return;
    }
    const input = {
        username: username,
        password: password
    };
    var key = username
    localStorage.setItem("key",key);
    
    /*
    const response = await fetch("http://localhost:8080/api/login",{method:"POST",headers:{"Content-Type" : "application/json"},body:input});
    if(!response){
        console.log("error")
    }
    else {
        console.log(response) 
        const token = response.headers.get("X-AUTH-TOKEN");
        localStorage.setItem("X-AUTH-TOKEN",token);
        const responseJson = await response.json();
        localStorage.setItem("USERNAME",responseJson.username);
        //location.href="http://127.0.0.1:5500/todo.main.html"
    };
    */
    /*
    const response = await postData(input,"http://localhost:8080/api/login");
    if(!response){
        console.log(response);
    }
    else {
        console.log(response) 
        const token = response.headers.get("X-AUTH-TOKEN");
        localStorage.setItem("X-AUTH-TOKEN",token);
        const responseJson = await response.json();
        localStorage.setItem("USERNAME",responseJson.username);
        location.href="http://127.0.0.1:5500/todo.main.html"
    };
    */

    try{const data = await fetch(`http://192.168.56.101:8080/sample/user/login/${username}`,{
        method:"GET",
        headers:{
            "Content-type":"application/json"
        },
     });
     var inside = await data.json();
     var userid = await inside.userId;
     localStorage.setItem("userid",userid);
     if(!data.ok){
         alert("Could not find User");
         document.getElementById("loading-screen").style.display = "none";
         return;
     }else if(!(data.length === 0)){
       window.location.href = "http://127.0.0.1:5500/todo.main.html"
     }
    }catch{
        alert("Could not catch response");
        document.getElementById("loading-screen").style.display = "none";
        return;
    }
    

}
//ロード完了のイベントをトリガーとしてローディング画面をオフにする。
window.addEventListener("load",function(){
   setTimeout(function(){ document.getElementById("loading-screen").style.display = "none";},3000)
});
//ユーザーがメイン画面にあるログアウトボタンを押すとローカルストレージからメイン画面を操作するのに必要な
//ユーザーネームとユーザーIDを消去し、ユーザーが戻ってきてもメイン画面を操作できない状態にしてからログイン画面へ遷移する処理。
function logout(){
    //localStorage.removeItem("X-AUTH-TOKEN");
    //localStorage.removeItem("USERNAME");
    localStorage.removeItem("key");
    localStorage.removeItem("userid");
    location.href = "http://127.0.0.1:5500/todo.login.html";
}

//メイン画面を操作しているユーザーの情報をユーザーがログインした時に受け取ってメイン画面に表示するための処理。
var username_element = localStorage.getItem("key");
var userid_element = localStorage.getItem("userid");
var text = `UserName : ${username_element}<br>UserId:${userid_element}`;
document.getElementById("test").innerHTML = text;

//ユーザー登録画面の登録ボタンを押したときにユーザーが新しくユーザーネームとパスワードをデータテーブルに登録する処理。
async function register(event){
    event.preventDefault();
    //ユーザーがボタンを押した時にユーザーが登録するユーザーネームの値を空白文字を消してから受け取る処理。
    var username = document.getElementById("username_register").value.replace(/[\s\u{3000}]/ug, '');
    //ユーザーがユーザーネームを空白のまま登録ボタンを押した時に警告を出して登録処理を終了させる処理。
    if(!username){
        alert("UserName Can Not To Be Empty or Using space only in your username is not allowed");
        return;
    //ユーザーネームにバックスラッシュが含まれている状態で登録ボタンを押した場合に警告を出して登録処理を終了させる処理。
    }else if(username.includes("\\")){
        alert("Can not include backslash in your username");
        return;
    }
    //ユーザーがボタンを押した時にユーザーが登録するパスワードを空白文字を消してから受け取る処理。
    var password = document.getElementById("password_register").value.replace(/[\s\u{3000}]/ug, '');
    //ユーザーがパスワードを空白のまま登録ボタンを押した時に警告を出して登録処理を終了させる処理。
    if(!password){
        alert("PassWard Can Not To Be Empty or Using space only in your password is not allowed");
        return;
    //パスワードにバックスラッシュが含まれている状態で登録ボタンを押した場合に警告を出して登録処理を終了させる処理。
    }else if(password.includes("\\")){
        alert("Can not include backslash in your password");
        return;
    }
    //ユーザーがデータテーブルに登録する値をJSON形式に変換して変数に格納する処理。
    const user = {
         username : username,
         password : password
    };
    //既に登録されているユーザーネームかを判断する処理。
    try{const data = await fetch(`http://192.168.56.101:8080/sample/user/login/${username}`,{
            method:"GET",
            headers:{
                "Content-type":"application/json"
            },
        });
        //既に同じユーザーネームが登録されている場合にユーザーにその旨を通知し、登録処理を終了させる処理。
        if(data.ok){
            alert("Sorry. The username is used by");
            return;
        }
           //既に同じユーザーネームが登録されていない場合にサーバにHTTPリクエストを送り、データテーブルにユーザー情報を登録する処理。
    }catch{const response = await fetch("http://192.168.56.101:8080/sample/user/register",{
                method:"POST",
                headers: {
                    "Content-Type" : "application/json"
                },
                body:JSON.stringify(user)
            });
            //エラーでユーザー情報を登録できなかった場合にユーザーに通知し登録処理を終了させる処理。
            if (!response.ok) {
                const error = await response.json();
                console.error(error);
                //var a = "Sorry. Couldn't register";
                //showToast(a);
                return;
            //ユーザー登録が成功した場合にその旨をユーザーに通知し、自動的にログイン画面に遷移する処理。
            }else{
                var b = "Completed Registration";
                var text = "Redirect to the login page automatically"
                showToast_2(b);
                setTimeout(function(){
                    showToast_2(text);
                }, 4000)
                setTimeout(function(){
                    location.href = "http://127.0.0.1:5500/todo.login.html"
                }, 7000)
        }
    }finally{
        //var a = "Sorry. Couldn't register";
        //showToast(a);
        //return;  
    }
    /*
    const todo = await fetch(`http://localhost:8080/user/find/${username}`,{
        method:"GET",
        headers:{
            "Content-Type" : "application/json"
        },
    });
    var todoData = await todo.json();
    var userId = todoData.userId;
    
    const result = await fetch(`http://localhost:8080/todo/register`,{
        method:"POST",
        headers:{
            "Content-type":"application/json"
        },
        body:JSON.stringify(userId),
    }); 
    if(!result.ok){
        const error = await result.json();
        console.error(error);
        var c = "Failed to Register todo";
        showToast(c);
        return;
    }else{
        var d = "Successfully Registered a todo.";
        var text = "And redirect to the login page automatically";
        showToast(d);
        setTimeout(function(){
            showToast(text);
        }, 3000)
        setTimeout(function(){
            location.href = "http://127.0.0.1:5500/todo.login.html"
        }, 6000)
    }
    */
}

/*async function fetchTodos(){
    const todos = await fetch("http://localhost:8080/todo");
    if(!todos.ok){
        throw new Error("Could not fetch todo")
    }
    const todoJson = await todos.json();
    renderTodo(todoJson);
}

//document.addEventListener("DOMContentLoaded", fetchTodo)

/*
function renderTodo(){
    const container = document.getElementById("container");
    if(!container){
        throw new Error("Could not find container")
    };
    /*todos.innerHTML="";
    const todoDiv = document.createElement("table");
    todoDiv.innerHTML=
    "<th>USER ID</th><th>DUE DATE</th><th>CONTENT</th><th>CREATED AT</th>";
    todoJson.todos.forEach((todo) => {
        todoDiv.innerHTML += `
        <tr>
            <td>${todo.userid}</td>
            <td>${todo.duedate}</td>
            <td>${todo.content}</td>
            <td>${todo.createdat}</td>
            <td>
            <button onclick="DeleteTodo(${todo.userid})">DELETE</button>
            </td>
        </tr>`;
            var ones = responseJson.split('|');
            let textareaCount = 0;
        for(var count = 0; count < response.length; count++){
            var one = ones.children[count]
            var textarea = document.createElement("textarea");
                textareaCount++;
                textarea.id="textarea" + textareaCount;
                textarea.value = one;
                container.appendChild(textarea);
        }
        
};
*/

//メイン画面にあるアップデートボタンを押すとメイン画面にある付箋の内容がデータテーブルにあるレコードの内容を上書きする処理。
async function Update(){
    var content = "";
    //
    var container = document.getElementById("container");
    var boxes = container.children;
    //メイン画面にアップデートする付箋が無い場合にその旨をユーザーに表示し、アップデート処理を終了させる処理。
    if(boxes.length == 0){
        alert("There is nothing to update");
        return;
    }
    //メイン画面にある付箋の数に応じてアップデート処理をループさせる処理。
    try{for( var i = 0; i < boxes.length;i++){
            content = boxes[i].children[1].value + "|";
            content += boxes[i].children[2].value;
        var contentJson = {"content" : content};
        var Id = boxes[i].id;
        const response = await fetch(`http://192.168.56.101:8080/sample/todo/${Id}`,{
            method:"PUT",
            headers:{
                "Content-Type" : "application/json"
            },
            body:JSON.stringify(contentJson)
        })
        if (!response.ok) {
            const result = await response.json();
            throw new Error(result.message);
        }
    }
}catch{
    var string = "Couldn't update";
    showToast(string);
    return;
}
    //ループしていたアップデート処理が一通り成功したら、その旨をユーザーに通知する処理。
    var text = "UPDATED"
    showToast(text);
}

   var draggedElementId = null;
//メイン画面にある追加ボタンを押すとメイン画面に新しい付箋が追加されると共に、
//その追加された付箋に対応する新しいレコードがデータテーブルに挿入される処理。    
async function add(){
    //データテーブルに新しいレコードを追加するHTTPリクエストに必要なユーザーIDを取得する処理。
    let userId = localStorage.getItem("userid");
    //データテーブルに新しいレコードを挿入する処理。
    try{const result = await fetch(`http://192.168.56.101:8080/sample/todo/register`,{
        method:"POST",
        headers:{
            "Content-type":"application/json"
        },
        body:JSON.stringify(userId),
        });
        //新しいレコードの挿入に失敗した場合にその旨をユーザーに通知し、挿入処理を終了させる処理。
        if(!result.ok){
            const error = await result.json();
            console.error(error);
            var e = "Failed To Register todo";
            showToast(e);
            return;
        //レコード挿入処理が成功した場合にその旨をユーザーに通知する処理。
        }else{
            var f = "Successfully Registered a todo ";
            showToast(f);
        }
    }catch{
        showToast(e);
        return; 
    }
    //新しくデータテーブルに挿入したレコードのIDを取得するためにサーバーにHTTPリクエストを送る処理。
    try{const id = await fetch(`http://192.168.56.101:8080/sample/todo/add/${userId}`,{
            method:"GET",
            headers:{
                "Content-type":"application/json"
            }
        })
        //ID取得処理に失敗した場合にその旨をユーザーに通知し、ID取得処理を終了させる処理。
        if(!id.ok){
            const error = await result.json();
            console.error(error);
            var g = "Failed To Get Id";
            showToast(g)
            return;
        //ID取得処理に成功した場合にその旨をユーザーに通知する処理。
        }else{
            var h = "Successfully got an Id ";
            setTimeout(function(){
                showToast(h);
            },3000);
        }
    
   //追加する付箋に含まれるテキストエリア要素を作成し属性を設定する処理。
    var textarea = document.createElement("textarea");
        textarea.className = "textarea";
        textarea.placeholder = "The use of | is prohibited. Within the 500 words limit."
        textarea.draggable = true;
        textarea.maxLength = "500";
        //テキストエリアに特定の文字が記入できなくする処理を付与する処理。
        textarea.addEventListener('keydown', function(event) {
            const restrictedChars = ["|"];
            
            const key = event.key.toLowerCase();
            
            if (restrictedChars.includes(key)) {
                event.preventDefault();
            }
        });
    /*
    var top = lastElementTop + lastElementHeight;
    var left = textarea.offsetLeft ;
        textarea.style.top = top + "px";
        textarea.style.left = left + "px";
        lastElementTop = top;
        lastElementHeight = textarea.offsetHeight;
    */
    //付箋に含まれる文字列を持つ要素を作成し属性を設定する処理。
        var label = document.createElement("label");
        label.style.backgroundColor = "aqua";
        label.textContent = "Due Date";
    //付箋に含まれる日付選択機能を持った要素を作成し属性を設定する処理。
    var date = document.createElement("input");
        date.type = "date";
        date.className = "date";
    //付箋に含まれる日付選択機能でユーザーがログインした日以前の日付を選択できないように設定する処理。
    var today = new Date().toISOString().split('T')[0];
        date.min = today;
    //付箋に含まれる各要素をひとまとめにするための入れ物としての要素を作成し属性を設定する処理。
    var box = document.createElement("div");
        //box.style.position = "absolute";
        box.className = "box";
    //ID取得処理で取得してきたIDを作成した要素のIDに代入する処理。
    var addedId = await id.json();
        box.id = addedId.id;
    //各子要素を親要素に追加する処理。
        box.appendChild(label);
        box.appendChild(date);
        box.appendChild(textarea);
    /*
    var offsetX, offsetY;
    var isDragging = false;
    box.addEventListener("mousedown",function(e){
        isDragging = true;
        offsetX = e.clientX - box.getBoundingClientRect().left;
        offsetY = e.clientY - box.getBoundingClientRect().top;
    })
    box.addEventListener("mousemove",function(e){
        if(isDragging){
            var x = e.clientX - offsetX;
            var y = e.clientY - offsetY;
            box.style.left = x + "px";
            box.style.top = y + "px";
        }
    box.addEventListener("mouseup", function(e){
        isDragging = false;
    })
    })
    */
    //親要素を追加する要素をHTMLから取得し、属性を設定する処理。
    var container = document.getElementById("container");
        container.style.display = "flex";
        container.style.flexDirection = "raw";
        container.style.flexWrap = "wrap";
        //親要素をドラッグした時にドラッグされた親要素のIDを取得する処理。
        box.addEventListener("dragstart",function(event){
            draggedElementId = event.target.parentNode.id;
        });
    /*
    var body = document.body;
        body.style.display = "flex";
        body.style.flexWrap = "wrap";
       box.addEventListener("mouseup", function(){
        console.log(box.offsetLeft,box.offsetTop,box.style.left,box.style.top,"座標");
       }) 
    */
       //HTMLから取得した要素に親要素を追加する処理。 
       container.appendChild(box);
    }catch{
        showToast(g)
        return;
    }
}
//ドラッグした要素をドロップする時にデフォルトの挙動をキャンセルする処理。
function allowDrop(event){
    event.preventDefault();
}

//メイン画面にあるゴミ箱アイコン上で重なるようにドラッグしてきた要素をドロップすると
//メイン画面上からは要素を消去しデータテーブル上からはレコードを消去する処理。
async function dropToDelete(){
    //ドロップされた要素自体と要素のIDを取得する処理。
    const draggedElement = document.getElementById(draggedElementId);
    var Id = draggedElementId;
    //要素をメイン画面上から消去する処理。
    draggedElement.remove();
    //取得した要素のIDを用いてサーバーにHTTPリクエストを送り、データテーブル上から要素に対応するレコードを消去する処理。
    try{const response = await fetch(`http://192.168.56.101:8080/sample/todo/${Id}`,{
            method:"DELETE",
            headers:{
                "Content-type":"application/json"
            },
    });
    //レコード消去処理に失敗した場合にその旨をユーザーに通知する処理。
    if(!response){
        var i = "Could Not Delete";
        showToast(i);
    //レコード消去処理に成功した場合にその旨をユーザーに通知する処理。
    }else{
        var j = "DELETED";
        showToast(j);
    }
}catch{
        showToast(i);
}
    //ドラッグして取得する要素のIDを格納する変数をリセットする。
    draggedElementId = null;
            
}

function showToast(text){
    var toastContainer = document.getElementById("toastContainer");
    toastContainer.textContent = `${text}`;
    toastContainer.className = "toast show";
    toastContainer.style.cursor = "pointer";
    setTimeout(function(){toastContainer.className = toastContainer.className.replace("show","");},3000);
    toastContainer.addEventListener('click', function() {
        console.log("Notification clicked! That's all.");
    });
}

function showToast_2(text){
    var toastContainer = document.getElementById("toastContainer");
    toastContainer.textContent = `${text}`;
    toastContainer.className = "toast2 show";
    toastContainer.style.cursor = "pointer";
    setTimeout(function(){toastContainer.className = toastContainer.className.replace("show","");},3000);
    toastContainer.addEventListener('click', function() {
        console.log("Notification clicked! That's all.");
    });
}

function info(){
    alert("Please Drop here to Delete a Sticky Note!")
}

async function CharacterCount(){
    var maxlength = 20;
    var current = document.getElementById("username_register").value;
    var currentLength = current.length;
    var remainig = maxlength - currentLength;
    document.getElementById("characterCount").innerHTML= remainig +  " characters remaining";
    var div = document.getElementById("characterCount");
    div.style.opacity = 1;
}

function HiddenCount(){
    var counter = document.getElementById("characterCount");
    counter.style.opacity = 0;
}

function PasswordCount(){
    var maxlength = 20;
    var currentLength = document.getElementById("password_register").value.length;
    var remainig = maxlength - currentLength;
    document.getElementById("passwordCount").innerText = remainig + " characters remaining";
    var div = document.getElementById("passwordCount");
    div.style.opacity = 1;
}
function HiddenPassword(){
    var counter = document.getElementById("passwordCount");
    counter.style.opacity = 0;
}