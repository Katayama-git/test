
            function increase(){
              var a = document.createElement("textarea");
              var box = document.getElementById("box");
              box.appendChild(a);
              console.log(box.children,"rfwefwf")
            }